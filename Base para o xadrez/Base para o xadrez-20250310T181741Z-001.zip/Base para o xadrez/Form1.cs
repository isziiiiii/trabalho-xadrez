using System.CodeDom.Compiler;
using System.Globalization;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography.X509Certificates;

namespace xadrez;
public partial class Form1 : Form
{
 private EnumerableExecutor turnoAtual = EnumerableExecutor.Branco; //começndo com as brancas
   private List<string> historicojogadas = new<string>();
       public static int sizeOfTabuleiro = 8;
    
    private PictureBox pecaSelecionada = null; // Armazena a peça selecionada
    private int origemX = -1, origemY = -1; // Armazena a posição da peça
    public Peca[,] tabuleiro = new Peca[sizeOfTabuleiro,sizeOfTabuleiro];
    public Form1()
    {}
    public void SalvarHistorico()
    {
    File.WriteAllLines("historico.txt", historicojogadas);
        InitializeComponent();
    }
    public void cliqueNoTabuleiro(Peca peca)
{

    if (origemX == -1 && origemY == -1) // Primeiro clique: seleciona a peça
    {
        if (peca is not CasaVazia){
            pecaSelecionada = peca.pictureBox;
            origemX = peca.x;
            origemY = peca.y;
            MessageBox.Show($"Peça selecionada em ({peca.x}, {peca.y})");
        {
            if (peca.cor != turnoAtual){
                MessageBox.Show("Não é sua vez!");
                return;
            }
        PublicKey static Rei EncontrarRei(Peca[,] tabuleiro, EnumerableExecutor cor)
        {
            foreach (Peca p in tabuleiro)
            {
                if (p is Rei && p.cor == cor)
                {
                    return (Rei) p;
                }
            }
        }
        return null
        }
        Public static bool EstarEmXeque(Peca[,] tabuleiro, EnumCor)
        {
            Rei rei =  EncontrarRei(tabuleirom, cor);
            if (rei == null)
            return false;

            foreach (Peca p in tabuleiro)
            {
                if (p != null && p.cor != CorFlags && p.validarMovimento(rei.çx, rei.y))
                {
                    return true;
                }
            }
            return false;
        
        }
        if (EstarEmxeque(tabuleiro, turnoAtual))
        {
            MessageBox.Show("Movimento inválido! voce não pode se colocar em xeque mate.");
            return;
        }
        }
    }
    else // Segundo clique: tenta mover a peça
    {
        Peca pecaOrigem = tabuleiro[origemX, origemY];
        Peca pecaDestino = tabuleiro[peca.x, peca.y];

        // Verifica se o movimento é válido
        if (!pecaOrigem.validarMovimento(peca.x, peca.y))
        {
        string movimento = $ "{pecaOrigem.GetType().Nsme} {pecaOrigem.cor}, de ({origemX}, {origemY}) para ({peca.x}, {peca.y})";
        historicojogadas.Add(movimento);
        {
            MessageBox.Show("Movimento Inválido!");
            pecaSelecionada = null;
            origemX = -1;
            origemY = -1;
            return;
        }
        
        if (pecaDestino is CasaVazia) // Se o destino estiver vazio, apenas move a peça
        {
            // Atualiza a matriz
                // Atualiza a matriz
                tabuleiro[origemX, origemY] = new CasaVazia(origemX * 50, origemY * 50, "casaVazia.png");
                tabuleiro[peca.x, peca.y] = pecaOrigem;

                // Atualiza as coordenadas da peça movida
                pecaOrigem.x = peca.x;
                pecaOrigem.y = peca.y;

                // Atualiza a posição visualmente
                pecaOrigem.pictureBox.Location = new Point(peca.x * 50, peca.y * 50);
                
        } 
        if (EstarEmXequeMate(turnoAtual))
        {
            MessageBox.Show($"xeque-mate! {turnoAtual} perdeu!");
            Application.Exit()
        }
       
                turnoAtual = (turnoAtual == EnumerableExecutor.Branco) ? EnumerableExecutor.Preto : EnumCor.Branco;
          MessageBox.Show($"Agora é sua vez das{turnAtual == EnumCor.Branco} ? "brancas" : "pretas")}");
            // Atualiza a matriz
        else // Se houver outra peça, troca as posições
        {
                // Remover peça do tabuleiro
                this.Controls.Remove(pecaDestino.pictureBox);

                // Substitui a peça no tabuleiro
                tabuleiro[peca.x, peca.y] = pecaOrigem;
                tabuleiro[origemX, origemY] = new CasaVazia(origemX * 50, origemY * 50, "casaVazia.png");

                // Atualiza a posição visualmente
                pecaOrigem.x = peca.x;
                pecaOrigem.y = peca.y;
                pecaOrigem.pictureBox.Location = new Point(peca.x * 50, peca.y * 50);
                {
                    public bool EstaEmXequeMate(EnumerableExecutor corDoRei){
                        if (! EstaEmXequeMate(tabuleiro, dorDoRei)) 
                        return false;

                        foreach (Peca p in tabuleiro){
                            if (p != null && p.cor == corDoReiRei){
                                for (int i - 0; i< 8; i++)
                                {
                                    for (int i= 0; i <8; i++)
                                    {
                                      if (p.validarMovimento(i, j))
                                      {
                                        return false;
                                      }
                                    }
                                }
                            }
                        }
                        return true;
                    }
                }
            {
      
            public void SalvarHistorico(){
                File.WriteAllLines("historico.txt", historicojogadas);
            }
            }
        }

        // Atualiza a interface
        this.Refresh();

        // Reseta os valores para a próxima jogada
        pecaSelecionada = null;
        origemX = -1;
        origemY = -1;
    }
}
}
