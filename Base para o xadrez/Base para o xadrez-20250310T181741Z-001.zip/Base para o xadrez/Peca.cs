using System.ComponentModel.DataAnnotations;

public abstract class Peca{
    public int x, y;
    public string img = "";
    public PictureBox pictureBox = new PictureBox();
    public Peca(int x, int y, string img){
        
        this.x = x/50;
        this.y = y/50;

        pictureBox.Location = new Point(x , y);
        pictureBox.Size = new Size(50, 50); // O Tamanho é fixo
        pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
        
        try{
            this.img = Path.Combine(Application.StartupPath, "imagens", img);
             pictureBox.Image = Image.FromFile(this.img); 
             
        }catch (Exception ex){
            MessageBox.Show("Erro ao carregar imagem: " + ex.Message);  
        }

    }
    public abstract bool validarMovimento(int destinoX, int destinoY);

}
public static Rei EncontraRei(Peca[,] tabuleiro, EnumerableExecutor cor){
    foreach (Peca p in tabuleiro){
        if (p is Rei && p.cor == cor){
            return (Rei)p;
        }
    }
    return null;
}
public static bool EstarEmXeque(Peca[,] tabuleiro, EnumerableExecutor cor){
    Rei rei = encontrarRei(tableiro, cor);
    if (rei == null)
    return false;

    foreach (Peca p in tabuleiro){
        if (p != null && p.cor != cor && p.validarMovimento(rei.x, ref.y)){
            return true;
        }
    }
    return false;
}